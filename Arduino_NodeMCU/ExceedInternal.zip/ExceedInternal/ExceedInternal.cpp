#include "ExceedInternal.h"

ExceedInternal::ExceedInternal() {}

ExceedInternal::~ExceedInternal() {
  delete se_read;
  delete se_write;
  delete[] receive_buffer;
  delete[] data_code_size;
}

void ExceedInternal::begin(
  uint8_t rx_write, 
  uint8_t tx_write,
  uint8_t rx_read,
  uint8_t tx_read,
  void (*callback)(char, void*)) {
    se_read = new SoftwareSerial(rx_write, tx_write);
    se_write = new SoftwareSerial(rx_read, tx_read);
    for (uint8_t i = 0; i < sizeof(data_code_size); i++) {
      data_code_size[i] = 0;
    }
    
    se_read->begin(9600);
    se_write->begin(9600);
    while (!se_read->isListening()) {
      se_read->listen();
    }

    data_callback = callback;
}

#ifdef EXCEED_INTERNAL_NODE_MCU
void ExceedInternal::sendToArduino(char code, void *data, char data_size) {
  char *b = (char*)data;
  char sent_size = 0;
  while (se_write->write(code) == 0) {
    delay(1);
  }
  while (sent_size < data_size) {
    sent_size += se_write->write(b, data_size);
    delay(1);
  }
}

void ExceedInternal::readSerial() {
  char ch = se_read->read();
  if (cur_recv_buffer_length == -1) {
    cur_data_header = ch;
    cur_recv_buffer_length = 0;
  } else if (cur_recv_buffer_length <= data_code_size[cur_data_header]) {
    receive_buffer[cur_recv_buffer_length++] = ch;
    if (cur_recv_buffer_length == data_code_size[cur_data_header]) {
      this->data_callback(cur_data_header, receive_buffer);
      cur_recv_buffer_length = -1;
    }
  }
}
#endif

#ifdef EXCEED_INTERNAL_ARDUINO
void ExceedInternal::sendToNodeMCU(char code, void *data, char data_size) {
  char *b = (char*)data;
  char sent_size = 0;
  while (se_write->write(code) == 0) {
    delay(1);
  }
  while (sent_size < data_size) {
    sent_size += se_write->write(b, data_size);
    delay(1);
  }
}

void ExceedInternal::readSerial() {
  if (se_read.available()) {
    char ch = se_read->read();
    if (cur_recv_buffer_length == -1) {
      cur_data_header = ch;
      cur_recv_buffer_length = 0;
    } else if (cur_recv_buffer_length <= data_code_size[cur_data_header]) {
      receive_buffer[cur_recv_buffer_length++] = ch;
      if (cur_recv_buffer_length == data_code_size[cur_data_header]) {
        this->data_callback(cur_data_header, receive_buffer);
        cur_recv_buffer_length = -1;
      }
    }
  }
}
#endif

void ExceedInternal::registerDataCode(const uint8_t code, const uint8_t data_size) {
  this->data_code_size[code] = data_size;
}

bool ExceedInternal::GET(const char *url, void (*callback)(String const&)) {
  HTTPClient main_client;
  //Serial.print("GET: ");
  //Serial.println(url);
  main_client.begin(url);
  if (main_client.GET() == HTTP_CODE_OK) {
    //Serial.println("GET REQUEST RESPONSE OK");
    if (callback != 0) {
      callback(main_client.getString());
    }
    return true;
  }
  //Serial.println("GET REQUEST ERROR");
  return false;
}

ExceedInternal ExceedLib;

