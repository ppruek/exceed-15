#ifndef EXCEED_INTERNAL_H
#define EXCEED_INTERNAL_H

#include <Arduino.h>
#include <stdint.h>

#if defined(__AVR_ATmega328P__) || defined(__AVR_ATmega168__)
#define EXCEED_INTERNAL_ARDUINO
#include <SoftwareSerial.h>
#endif
#if defined(ESP8266)
#define EXCEED_INTERNAL_NODE_MCU
#include <ESP8266HTTPClient.h>
#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <EspSoftwareSerial.h>
#endif

class ExceedInternal {
  private:
    SoftwareSerial *se_read;
    SoftwareSerial *se_write;
    char data_code_size[32];
    char receive_buffer[256];
    uint8_t cur_recv_buffer_length = 0;
    uint8_t cur_data_header;
    
    void (*data_callback)(char, void*);

    struct Dummy {
      uint16_t dummy1;
      uint16_t dummy2;
    } dummy;
    
  public:
    ExceedInternal();
    ~ExceedInternal();
    void begin(
      uint8_t rx_write, 
      uint8_t tx_write, 
      uint8_t rx_read, 
      uint8_t tx_read,
      void (*callback)(char, void*));
    
#ifdef EXCEED_INTERNAL_ARDUINO
    void sendToNodeMCU(char code, void *data, char data_size);
    void readSerial();
#endif

#ifdef EXCEED_INTERNAL_NODE_MCU
    void sendToArduino(char code, void *data, char data_size);
    void readSerial();
#endif

    void registerDataCode(const uint8_t code, const uint8_t data_size);

    bool GET(const char *url, void (*callback)(String const&));
};

extern ExceedInternal ExceedLib;

#endif // EXCEED_INTERNAL_H
